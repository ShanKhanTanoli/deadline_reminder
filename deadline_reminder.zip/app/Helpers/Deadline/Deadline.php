<?php

namespace App\Helpers\Deadline;
use App\Helpers\Deadline\Traits\DeadlineChronology;

class Deadline
{
    use DeadlineChronology;
}
