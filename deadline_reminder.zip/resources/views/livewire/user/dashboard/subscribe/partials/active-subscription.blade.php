<div class="card my-4">
    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
            <h6 class="text-white text-capitalize ps-3">
                Active Subscription
            </h6>
        </div>
    </div>
    <div class="card-body px-0 pb-2">
        <div class="container">
            <div class="text-success text-center">
                <i class="fas fa-5x fa-check-circle"></i>
            </div>
            <div class="text-success text-center">
                <strong>
                    You are Subscribed.
                </strong>
            </div>
        </div>
    </div>
</div>
