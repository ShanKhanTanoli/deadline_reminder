<div class="container-fluid">
    <?php echo $__env->make('errors.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row mt-3 d-flex">
        <div class="col-8">

            <?php if(Auth::user()->subscriptions()->active()->count() > 0): ?>
                <!--Begin::Already has an active subscription-->
                <?php echo $__env->make(
                    'livewire.user.dashboard.subscribe.partials.active-subscription'
                , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--End::Already has an active subscription-->
            <?php else: ?>
                <!--Begin::Payment Details-->
                <?php echo $__env->make(
                    'livewire.user.dashboard.subscribe.partials.payment-details'
                , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--End::Payment Details-->
            <?php endif; ?>

        </div>
        <div class="col-4">
            <?php if($plan = Admin::FindPrice($price)): ?>
            <!--Begin::Plan Info-->
            <?php echo $__env->make('livewire.user.dashboard.subscribe.partials.plan-details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--End::Plan Info-->
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH E:\XAMPP\htdocs\deadline_reminder\resources\views/livewire/user/dashboard/subscribe/index.blade.php ENDPATH**/ ?>