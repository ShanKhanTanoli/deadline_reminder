<div class="col-lg-3">
    <div class="card position-sticky">
        <ul class="nav flex-column bg-white border-radius-lg p-3">
            <li wire:ignore.self class="nav-item <?php if(Request::path() == 'Admin/Settings/General'): ?> active bg-gradient-primary <?php else: ?> <?php endif; ?>">
                <a wire:ignore.self
                    class="nav-link text-dark d-flex <?php if(Request::path() == 'Admin/Settings/General'): ?> active text-white <?php else: ?> <?php endif; ?>"
                    href="<?php echo e(route('AdminSettings')); ?>">
                    <i class="fas fa-cog me-2"></i>
                    <span class="text-sm">General</span>
                </a>
            </li>
            <li wire:ignore.self class="nav-item <?php if(Request::path() == 'Admin/Settings/Profile'): ?> active bg-gradient-primary <?php else: ?> <?php endif; ?>">
                <a wire:ignore.self
                    class="nav-link text-dark d-flex <?php if(Request::path() == 'Admin/Settings/Profile'): ?> active text-white <?php else: ?> <?php endif; ?>"
                    href="<?php echo e(route('AdminEditProfile')); ?>">
                    <i class="fas fa-user-edit me-2"></i>
                    <span class="text-sm">Profile</span>
                </a>
            </li>
            <li wire:ignore.self class="nav-item <?php if(Request::path() == 'Admin/Settings/Password'): ?> active bg-gradient-primary <?php else: ?> <?php endif; ?>">
                <a wire:ignore.self
                    class="nav-link text-dark d-flex <?php if(Request::path() == 'Admin/Settings/Password'): ?> active text-white <?php else: ?> <?php endif; ?>"
                    href="<?php echo e(route('AdminEditPassword')); ?>">
                    <i class="fas fa-lock me-2"></i>
                    <span class="text-sm">Password</span>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH E:\XAMPP\htdocs\deadline_reminder\resources\views/livewire/admin/dashboard/settings/partials/sidebar.blade.php ENDPATH**/ ?>