<div class="card my-4">
    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
            <h6 class="text-white text-capitalize ps-3">
                Plan Details
            </h6>
        </div>
    </div>
    <div class="card-body px-0 pb-2">
        <div class="container">
            <ul class="list-group mb-3">
                <li class="list-group-item d-flex justify-content-between lh-sm">
                    <div>
                        <h6 class="my-0">
                            Plan
                        </h6>
                    </div>
                    <span class="text-muted">
                        <?php if($findproduct = Admin::FindProduct($product)): ?>
                            <?php echo e($findproduct->name); ?>

                        <?php else: ?>
                            <?php echo e(__('NOT FOUND')); ?>

                        <?php endif; ?>
                    </span>
                </li>
                <?php if($plan->type == 'recurring'): ?>
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0">
                                Period
                            </h6>
                        </div>
                        <span class="text-muted">
                            <?php echo e($plan->recurring->interval_count); ?>

                            <?php echo e(Str::ucfirst($plan->recurring->interval)); ?>

                        </span>
                    </li>
                <?php endif; ?>
                <?php if($product = Admin::FindProduct($plan->product)): ?>
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0">
                                Create
                            </h6>
                        </div>
                        <span class="text-muted">
                            <?php if($find = $product->metadata->customers): ?>
                                <?php echo $find; ?> Customers
                            <?php else: ?>
                                Unlimited Customers
                            <?php endif; ?>
                        </span>
                    </li>
                <?php endif; ?>
                <?php if($product = Admin::FindProduct($plan->product)): ?>
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0">
                                Create
                            </h6>
                        </div>
                        <span class="text-muted">
                            <?php if($find = $product->metadata->deadlines): ?>
                                <?php echo $find; ?> Deadlines
                            <?php else: ?>
                                Unlimited Deadlines
                            <?php endif; ?>
                        </span>
                    </li>
                <?php endif; ?>
                <li class="list-group-item d-flex justify-content-between">
                    <div>
                        <h6 class="my-0">
                            Sub Total
                        </h6>
                    </div>
                    <strong><?php echo e($plan->unit_amount / 100); ?> <?php echo e(strtoupper($plan->currency)); ?></strong>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH E:\XAMPP\htdocs\deadline_reminder\resources\views/livewire/user/dashboard/subscribe/partials/plan-details.blade.php ENDPATH**/ ?>