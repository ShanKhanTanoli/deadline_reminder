<div class="container-fluid">
    <?php echo $__env->make('errors.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row mb-4">
        <div class="col-xl-6 col-sm-6 mb-xl-0 mb-4">
            <a href="<?php echo e(route('UserSubscriptions')); ?>">
                <div class="card">
                    <div class="card-header p-3 pt-2" style="border-radius: 0;">
                        <div
                            class="icon icon-lg icon-shape bg-gradient-primary shadow-dark text-center border-radius-xl mt-n4 position-absolute">
                            <i class="fas fa-credit-card opacity-10"></i>
                        </div>
                        <div class="text-end pt-1">
                            <p class="text-sm mb-0 text-capitalize">
                                Subscriptions
                            </p>
                            <h4 class="mb-0">
                                <?php echo e(User::CountSubscriptions(Auth::user())); ?>

                            </h4>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-6 col-sm-6 mb-xl-0 mb-4">
            <a href="<?php echo e(route('UserPlatformPlans')); ?>">
                <div class="card">
                    <div class="card-header p-3 pt-2" style="border-radius: 0;">
                        <div
                            class="icon icon-lg icon-shape bg-gradient-primary shadow-dark text-center border-radius-xl mt-n4 position-absolute">
                            <i class="fas fa-box-open opacity-10"></i>
                        </div>
                        <div class="text-end pt-1">
                            <p class="text-sm mb-0 text-capitalize">
                                Platform Plans
                            </p>
                            <h4 class="mb-0">
                                <?php echo e(Admin::CountActiveProducts()); ?>

                            </h4>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <div class="row mt-4">
        <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 mb-lg-0 mt-4">
                <div class="card shadow-lg">
                    <span class="badge rounded-pill bg-primary text-white mx-auto mt-5">
                        <?php if($plan = Admin::FindProduct($subscription->name)): ?>
                            <?php echo e($plan->name); ?>

                        <?php endif; ?>
                    </span>
                    <div class="card-header text-center pt-4 pb-3">
                        <h1 class="font-weight-bold mt-2">
                            <small class="text-lg align-top me-1">
                                <?php if($price = Admin::FindPrice($subscription->stripe_price)): ?>
                                    <?php echo e(Str::upper($price->currency)); ?>

                                <?php endif; ?>
                            </small>
                            <?php if($price = Admin::FindPrice($subscription->stripe_price)): ?>
                                <?php echo e($price->unit_amount / 100); ?>

                            <?php endif; ?>
                            <small class="text-lg">/
                                <?php if($price = Admin::FindPrice($subscription->stripe_price)): ?>
                                    <?php echo e($price->recurring->interval_count); ?>

                                    <?php echo e(Str::ucfirst($price->recurring->interval)); ?>

                                <?php endif; ?>
                            </small>
                        </h1>
                    </div>
                    <div class="card-body text-lg-start text-center pt-0">
                        <div class="text-center p-2 mb-2">
                            <span class="ps-3 text-dark">
                                <?php if($plan = Admin::FindProduct($subscription->name)): ?>
                                    <?php echo e($plan->description); ?>

                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="justify-content-start p-2 text-center mb-2">
                            <span class="ps-3 text-dark">
                                <i class="fas fa-check text-success" aria-hidden="true"></i>
                                <?php if($customers = Admin::FindProduct($subscription->name)->metadata->customers): ?>
                                    <?php echo e($customers); ?> Customers
                                <?php else: ?>
                                    Unlimited Customers
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="justify-content-start p-2 text-center mb-2">
                            <span class="ps-3 text-dark">
                                <i class="fas fa-check text-success" aria-hidden="true"></i>
                                <?php if($deadlines = Admin::FindProduct($subscription->name)->metadata->deadlines): ?>
                                    <?php echo e($deadlines); ?> Deadlines
                                <?php else: ?>
                                    Unlimited Deadlines
                                <?php endif; ?>
                            </span>
                        </div>
                        <!--Begin::If not ended-->
                        <?php if($subscription->stripe_status == 'active'): ?>
                            <!--Begin::If canceled-->
                            <?php if(Auth::user()->subscription($subscription->name)->canceled()): ?>
                                <td class="align-middle">
                                    <form wire:submit.prevent='Resume("<?php echo e($subscription->name); ?>")'>
                                        <button type="submit" class="btn btn-sm btn-info" style="width:100%;">
                                            <span wire:loading wire:target='Resume("<?php echo e($subscription->name); ?>")'
                                                class="spinner-border spinner-border-sm" role="status"
                                                aria-hidden="true"></span>
                                            Resume
                                        </button>
                                    </form>
                                </td>
                            <?php else: ?>
                                <td class="align-middle">
                                    <form wire:submit.prevent='Cancel("<?php echo e($subscription->name); ?>")'>
                                        <button type="submit" class="btn btn-danger" style="width:100%;">
                                            <span wire:loading wire:target='Cancel("<?php echo e($subscription->name); ?>")'
                                                class="spinner-border spinner-border-sm" role="status"
                                                aria-hidden="true"></span>
                                            Cancel
                                        </button>
                                    </form>
                                </td>
                            <?php endif; ?>
                            <!--End::If canceled-->

                            <!--If ended-->
                        <?php else: ?>
                            <?php if($subscription->stripe_status !== 'canceled'): ?>
                                <td class="align-middle">
                                    <button class="btn btn-danger disabled" style="width:100%;">
                                        Actions
                                    </button>
                                </td>
                            <?php endif; ?>
                        <?php endif; ?>


                        <!--Begin::If not ended-->
                        <?php if($subscription->stripe_status == 'canceled'): ?>
                            <td class="align-middle">
                                <button class="btn btn-danger disabled" style="width:100%;">
                                    Ended
                                </button>
                            </td>
                        <?php else: ?>
                            <td class="align-middle">
                                <form wire:submit.prevent='End("<?php echo e($subscription->name); ?>")'>
                                    <button type="submit" class="btn btn-danger" style="width:100%;">
                                        <span wire:loading wire:target='End("<?php echo e($subscription->name); ?>")'
                                            class="spinner-border spinner-border-sm" role="status"
                                            aria-hidden="true"></span>
                                        End
                                    </button>
                                </form>
                            </td>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH E:\XAMPP\htdocs\deadline_reminder\resources\views/livewire/user/dashboard/subscriptions/index.blade.php ENDPATH**/ ?>