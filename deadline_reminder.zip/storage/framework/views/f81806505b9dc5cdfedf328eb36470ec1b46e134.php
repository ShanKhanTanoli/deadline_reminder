<div class="container-fluid">
    <?php echo $__env->make('errors.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <?php if(Admin::CountActiveProducts()): ?>
            <!--Begin::Platform Prices-->
            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--Begin::If Price is Active-->
                <?php if($price->active): ?>
                    <!--Begin::If Product is Active-->
                    <?php if($product = Admin::FindProduct($price->product)->active): ?>
                        <div class="col-lg-4 mb-lg-0 mt-4">
                            <div class="card shadow-lg">
                                <span class="badge rounded-pill bg-primary text-white mx-auto mt-5">
                                    <?php if($product = Admin::FindProduct($price->product)): ?>
                                        <?php echo e($product->name); ?>

                                    <?php else: ?>
                                        Not Found
                                    <?php endif; ?>
                                </span>
                                <div class="card-header text-center pt-4 pb-3">
                                    <h1 class="font-weight-bold mt-2">
                                        <small class="text-lg align-top me-1">
                                            <?php echo e(strtoupper($price->currency)); ?>

                                        </small><?php echo e($price->unit_amount / 100); ?>

                                        <?php if($price->type == 'recurring'): ?>
                                            <small class="text-lg">/
                                                <?php echo e($price->recurring->interval_count); ?>

                                                <?php echo e(Str::ucfirst($price->recurring->interval)); ?>

                                            </small>
                                        <?php endif; ?>
                                    </h1>
                                </div>
                                <div class="card-body text-lg-start text-center pt-0">
                                    <?php if($product = Admin::FindProduct($price->product)): ?>
                                        <div class="text-center p-2">
                                            <span class="ps-3 text-dark">
                                                <?php echo $product->description; ?>

                                            </span>
                                        </div>
                                    <?php endif; ?>

                                    <?php if($product = Admin::FindProduct($price->product)): ?>
                                        <div class="justify-content-start p-2">
                                            <span class="ps-3 text-dark">
                                                <i class="fas fa-check"></i>
                                                <?php if($find = $product->metadata->customers): ?>
                                                    <?php echo $find; ?> Customers
                                                <?php else: ?>
                                                    Unlimited Customers
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    <?php endif; ?>

                                    <?php if($product = Admin::FindProduct($price->product)): ?>
                                        <div class="justify-content-start p-2">
                                            <span class="ps-3 text-dark">
                                                <i class="fas fa-check"></i>
                                                <?php if($find = $product->metadata->deadlines): ?>
                                                    <?php echo $find; ?> Deadlines
                                                <?php else: ?>
                                                    Unlimited Deadlines
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(Auth::user()->subscribed($price->product)): ?>
                                        <button type="button" style="width: 100%;"
                                            class="btn btn-lg bg-gradient-success btn-block mt-3 mb-0 disabled">
                                            <i class="fas fa-check"></i>
                                            Subscribed
                                        </button>
                                    <?php else: ?>
                                        <?php if(Auth::user()->subscriptions()->active()->count() > 0): ?>
                                            <button type="button" style="width: 100%;"
                                                class="btn btn-lg bg-gradient-primary btn-block mt-3 mb-0 disabled">
                                                Subscribe
                                            </button>
                                        <?php else: ?>
                                            <?php if($price->unit_amount > 0): ?>
                                                <form wire:submit.prevent="Subscribe('<?php echo e($price->id); ?>')">
                                                    <button type="submit" style="width: 100%;" wire:attrib='disabled'
                                                        class="btn btn-lg bg-gradient-primary btn-block mt-3 mb-0">
                                                        Subscribe
                                                        <span wire:loading
                                                            wire:target="Subscribe('<?php echo e($price->id); ?>')"
                                                            class="spinner-border spinner-border-sm" role="status"
                                                            aria-hidden="true">
                                                        </span>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <form wire:submit.prevent="Free('<?php echo e($price->id); ?>')">
                                                    <button type="submit" style="width: 100%;" wire:attrib='disabled'
                                                        class="btn btn-lg bg-gradient-primary btn-block mt-3 mb-0">
                                                        Free
                                                        <span wire:loading wire:target="Free('<?php echo e($price->id); ?>')"
                                                            class="spinner-border spinner-border-sm" role="status"
                                                            aria-hidden="true">
                                                        </span>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <!--End::If Product is Active-->
                <?php endif; ?>
                <!--End::If Price is Active-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--End::Platform Prices-->
        <?php else: ?>
            <div class="alert alert-danger text-white text-center">
                <strong>
                    Plans will be available soon.
                </strong>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH E:\XAMPP\htdocs\deadline_reminder\resources\views/livewire/user/dashboard/platform-plans/index.blade.php ENDPATH**/ ?>